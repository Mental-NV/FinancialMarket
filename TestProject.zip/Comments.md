# Comments
1. Handling different product applications in a single method is definitely not a good design. Thus I separated them into a few methods.
2. Since we changed IProductApplicationService interface it is a breaking change. If we have external clients who use the old version of IProductApplicationService we need to keep it as version V1 and introduce the modified service as V2. It is not clear to me if I should add versioning support. In the real world, I would discuss it with the team.
3. I made interface ISellerApplication a generic interface because it is not comfortable to use IProduct there.


