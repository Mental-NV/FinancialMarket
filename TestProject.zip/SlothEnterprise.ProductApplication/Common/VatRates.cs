﻿namespace SlothEnterprise.ProductApplication.Common
{
    /// <summary>
    /// Vat Rates constants
    /// </summary>
    public static class VatRates
    {
        /// <summary>
        /// UK Vat rate
        /// </summary>
        public const decimal UkVatRate = 0.20M;
    }
}