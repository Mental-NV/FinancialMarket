﻿namespace SlothEnterprise.ProductApplication.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using SlothEnterprise.External;

    /// <summary>
    /// Application result data model
    /// </summary>
    public class ApplicationResult : IApplicationResult
    {
        /// <summary>
        /// Application id
        /// </summary>
        public int? ApplicationId { get; set; }

        /// <summary>
        /// Success
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// List of errors
        /// </summary>
        public IList<string> Errors { get; set; } = new List<string>();
    }
}
