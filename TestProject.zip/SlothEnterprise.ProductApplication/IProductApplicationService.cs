﻿namespace SlothEnterprise.ProductApplication
{
    using SlothEnterprise.External;
    using SlothEnterprise.ProductApplication.Applications;

    public interface IProductApplicationService
    {
        IApplicationResult SubmitApplicationFor(SelectInvoiceApplication application);

        IApplicationResult SubmitApplicationFor(ConfidentialInvoiceApplication application);

        IApplicationResult SubmitApplicationFor(BusinessLoansApplication application);
    }
}