﻿namespace SlothEnterprise.ProductApplication
{
    using System;
    using System.Diagnostics;
    using SlothEnterprise.External;
    using SlothEnterprise.External.V1;
    using SlothEnterprise.ProductApplication.Applications;
    using SlothEnterprise.ProductApplication.Models;
    using SlothEnterprise.ProductApplication.Products;

    public class ProductApplicationService : IProductApplicationService
    {
        private readonly ISelectInvoiceService _selectInvoiceService;
        private readonly IConfidentialInvoiceService _confidentialInvoiceWebService;
        private readonly IBusinessLoansService _businessLoansService;

        public ProductApplicationService(ISelectInvoiceService selectInvoiceService, IConfidentialInvoiceService confidentialInvoiceWebService, IBusinessLoansService businessLoansService)
        {
            _selectInvoiceService = selectInvoiceService ?? throw new ArgumentNullException(nameof(selectInvoiceService));
            _confidentialInvoiceWebService = confidentialInvoiceWebService ?? throw new ArgumentNullException(nameof(confidentialInvoiceWebService));
            _businessLoansService = businessLoansService ?? throw new ArgumentNullException(nameof(businessLoansService));
        }

        public IApplicationResult SubmitApplicationFor(SelectInvoiceApplication application)
        {
            // Validate input parameters
            if (application is null)
            {
                throw new ArgumentNullException(nameof(application));
            }
            if (application.CompanyData is null)
            {
                throw new ArgumentNullException(nameof(application.CompanyData));
            }
            if (application.Product is null)
            {
                throw new ArgumentNullException(nameof(application.Product));
            }

            IApplicationResult result = new ApplicationResult();
            try
            {
                // Submit the application
                int applicationId = _selectInvoiceService.SubmitApplicationFor(
                    application.CompanyData.Number.ToString(), 
                    application.Product.InvoiceAmount, 
                    application.Product.AdvancePercentage);
                if (applicationId > -1)
                {
                    result.ApplicationId = applicationId;
                    result.Success = true; // Mark a success operation
                }
            }
            catch (Exception ex)
            {
                // Operation failed. Log the errors.
                result.Success = false;
                result.ApplicationId = -1;
                result.Errors.Add(ex.ToString());
                Trace.TraceError($"Select Invoice Discount application submission for company number {application.CompanyData.Number} and ProductId {application.Product.Id} failed with an error: {ex}");
            }
            return result;

        }

        public IApplicationResult SubmitApplicationFor(ConfidentialInvoiceApplication application)
        {
            // Validate input parameters
            if (application is null)
            {
                throw new ArgumentNullException(nameof(application));
            }
            if (application.CompanyData is null)
            {
                throw new ArgumentNullException(nameof(application.CompanyData));
            }
            if (application.Product is null)
            {
                throw new ArgumentNullException(nameof(application.Product));
            }

            IApplicationResult result = new ApplicationResult();
            try
            {
                // Submit the application
                result = _confidentialInvoiceWebService.SubmitApplicationFor(
                    application.CompanyData.ToCompanyDataReqest(), 
                    application.Product.TotalLedgerNetworth, 
                    application.Product.AdvancePercentage, 
                    application.Product.VatRate);
            }
            catch (Exception ex)
            {
                // Operation failed. Log the errors
                result.Success = false;
                result.Errors.Add(ex.ToString());
                Trace.TraceError($"Confidential Invoice Discount application submission for company number {application.CompanyData.Number} and product id {application.Product.Id} failed with an error: {ex}");
            }
            return result;
        }

        public IApplicationResult SubmitApplicationFor(BusinessLoansApplication application)
        {
            // Validate input parameters
            if (application is null)
            {
                throw new ArgumentNullException(nameof(application));
            }
            if (application.CompanyData is null)
            {
                throw new ArgumentNullException(nameof(application.CompanyData));
            }
            if (application.Product is null)
            {
                throw new ArgumentNullException(nameof(application.Product));
            }

            IApplicationResult result = new ApplicationResult();
            try
            {
                // Submit the application
                result = _businessLoansService.SubmitApplicationFor(
                    application.CompanyData.ToCompanyDataReqest(), 
                    new LoansRequest
                    {
                        InterestRatePerAnnum = application.Product.InterestRatePerAnnum,
                        LoanAmount = application.Product.LoanAmount
                    });
            }
            catch (Exception ex)
            {
                // Operation failed. Log the errors
                result.Success = false;
                result.Errors.Add(ex.ToString());
                Trace.TraceError($"Confidential Invoice Discount application submission for company number {application.CompanyData.Number} and product id {application.Product.Id} failed with an error: {ex}");
            }
            return result;
        }
    }
}
