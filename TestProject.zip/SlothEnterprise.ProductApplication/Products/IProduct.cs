﻿namespace SlothEnterprise.ProductApplication.Products
{
    /// <summary>
    /// Abstaction for a product
    /// </summary>
    public interface IProduct
    {
        /// <summary>
        /// Product id
        /// </summary>
        int Id { get; }
    }
}
