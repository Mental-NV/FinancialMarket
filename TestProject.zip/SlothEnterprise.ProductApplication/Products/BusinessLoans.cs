﻿namespace SlothEnterprise.ProductApplication.Products
{
    /// <summary>
    /// Represent data for Business Loans product
    /// </summary>
    public class BusinessLoans : IProduct
    {
        /// <summary>
        /// Product id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Per annum interest rate
        /// </summary>
        public decimal InterestRatePerAnnum { get; set; }

        /// <summary>
        /// Total available amount to withdraw
        /// </summary>
        public decimal LoanAmount { get; set; }
    }
}