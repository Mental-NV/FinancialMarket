﻿namespace SlothEnterprise.ProductApplication.Products
{
    using SlothEnterprise.ProductApplication.Common;

    /// <summary>
    /// Represent data for Confidential Invoice Discount product
    /// </summary>
    public class ConfidentialInvoiceDiscount : IProduct
    {
        /// <summary>
        /// Product id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// TotalLedgerNetworth
        /// </summary>
        public decimal TotalLedgerNetworth { get; set; }

        /// <summary>
        /// AdvancePercentage
        /// </summary>
        public decimal AdvancePercentage { get; set; }

        /// <summary>
        /// Vat rate
        /// </summary>
        public decimal VatRate { get; set; } = VatRates.UkVatRate;
    }
}