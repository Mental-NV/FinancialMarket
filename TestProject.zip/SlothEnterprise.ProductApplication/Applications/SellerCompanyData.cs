﻿namespace SlothEnterprise.ProductApplication.Applications
{
    using SlothEnterprise.External;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class SellerCompanyData : ISellerCompanyData
    {
        public string Name { get; set; }
        public int Number { get; set; }
        public string DirectorName { get; set; }
        public DateTime Founded { get; set; }

        public CompanyDataRequest ToCompanyDataReqest()
        {
            return new CompanyDataRequest()
            {
                 CompanyFounded = Founded,
                 DirectorName = DirectorName,
                 CompanyName = Name,
                 CompanyNumber = Number
            };
        }
    }
}
