﻿namespace SlothEnterprise.ProductApplication.Applications
{
    using SlothEnterprise.External;
    using SlothEnterprise.ProductApplication.Products;

    public class BusinessLoansApplication : ISellerApplication<BusinessLoans, SellerCompanyData>
    {
        public BusinessLoans Product { get; set; }
        public SellerCompanyData CompanyData { get; set; }
    }
}
