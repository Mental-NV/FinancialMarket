﻿namespace SlothEnterprise.ProductApplication.Applications
{
    using SlothEnterprise.External;
    using SlothEnterprise.ProductApplication.Products;

    public class ConfidentialInvoiceApplication : ISellerApplication<ConfidentialInvoiceDiscount, SellerCompanyData>
    {
        public ConfidentialInvoiceDiscount Product { get; set; }
        public SellerCompanyData CompanyData { get; set; }
    }
}
