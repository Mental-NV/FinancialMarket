﻿namespace SlothEnterprise.ProductApplication.Applications
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface ISellerCompanyData
    {
        string Name { get; set; }
        int Number { get; set; }
        string DirectorName { get; set; }
        DateTime Founded { get; set; }
    }
}
