﻿using SlothEnterprise.External;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;
using System.Text;

namespace SlothEnterprise.ProductApplication.Applications
{
    public interface ISellerApplication<T, K> where T: IProduct where K: ISellerCompanyData
    {
        T Product { get; set; }
        K CompanyData { get; set; }
    }
}
