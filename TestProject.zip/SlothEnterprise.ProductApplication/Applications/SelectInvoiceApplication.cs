﻿namespace SlothEnterprise.ProductApplication.Applications
{ 
    using SlothEnterprise.External;
    using SlothEnterprise.ProductApplication.Products;

    public class SelectInvoiceApplication : ISellerApplication<SelectiveInvoiceDiscount, SellerCompanyData>
    {
        public SelectiveInvoiceDiscount Product { get; set; }
        public SellerCompanyData CompanyData { get; set; }
    }
}
