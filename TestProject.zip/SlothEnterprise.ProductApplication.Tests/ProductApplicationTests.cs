﻿namespace SlothEnterprise.ProductApplication.Tests
{
    using FluentAssertions;
    using Moq;
    using SlothEnterprise.External;
    using SlothEnterprise.External.V1;
    using SlothEnterprise.ProductApplication.Applications;
    using SlothEnterprise.ProductApplication.Products;
    using Xunit;

    public class ProductApplicationTests
    {
        Mock<IApplicationResult> _appResult;

        public ProductApplicationTests()
        {
            _appResult = new Mock<IApplicationResult>();
            _appResult.SetupProperty(p => p.ApplicationId, 1);
            _appResult.SetupProperty(p => p.Success, true);
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithSelectInvoiceDiscount_ShouldReturnOne()
        {
            var productApplicationService = new Mock<IProductApplicationService>();
            IProductApplicationService _sut = productApplicationService.Object;
            productApplicationService.Setup(m => m.SubmitApplicationFor(It.IsAny<SelectInvoiceApplication>())).Returns(_appResult.Object);

            SelectInvoiceApplication sellerApplication = new SelectInvoiceApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new SelectiveInvoiceDiscount()
            };

            Mock<ISelectInvoiceService> _selectInvoiceServiceMock = new Mock<ISelectInvoiceService>();
            _selectInvoiceServiceMock.Setup(m => m.SubmitApplicationFor(It.IsAny<string>(), It.IsAny<decimal>(), It.IsAny<decimal>())).Returns(1);
            IApplicationResult result = _sut.SubmitApplicationFor(sellerApplication);
            Assert.Equal(1, result.ApplicationId);
            Assert.True(result.Success);
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithConfidentialInvoiceDiscount_ShouldReturnOne()
        {
            var productApplicationService = new Mock<IProductApplicationService>();
            IProductApplicationService _sut = productApplicationService.Object;
            productApplicationService.Setup(m => m.SubmitApplicationFor(It.IsAny<ConfidentialInvoiceApplication>())).Returns(_appResult.Object);

            ConfidentialInvoiceApplication sellerApplication = new ConfidentialInvoiceApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new ConfidentialInvoiceDiscount()
            };

            Mock<IConfidentialInvoiceService> _confidentialInvoiceServiceMock = new Mock<IConfidentialInvoiceService>();
            _confidentialInvoiceServiceMock.Setup(m => m.SubmitApplicationFor(It.IsAny<CompanyDataRequest>(), It.IsAny<decimal>(), It.IsAny<decimal>(), It.IsAny<decimal>())).Returns(_appResult.Object);
            IApplicationResult result = _sut.SubmitApplicationFor(sellerApplication);
            Assert.Equal(1, result.ApplicationId);
            Assert.True(result.Success);
        }

        [Fact]
        public void ProductApplicationService_SubmitApplicationFor_WhenCalledWithBusinessLoans_ShouldReturnOne()
        {
            var productApplicationService = new Mock<IProductApplicationService>();
            IProductApplicationService _sut = productApplicationService.Object;
            productApplicationService.Setup(m => m.SubmitApplicationFor(It.IsAny<BusinessLoansApplication>())).Returns(_appResult.Object);

            BusinessLoansApplication sellerApplication = new BusinessLoansApplication()
            {
                CompanyData = new SellerCompanyData(),
                Product = new BusinessLoans()
            };

            Mock<IBusinessLoansService> _confidentialInvoiceServiceMock = new Mock<IBusinessLoansService>();
            _confidentialInvoiceServiceMock.Setup(m => m.SubmitApplicationFor(It.IsAny<CompanyDataRequest>(), It.IsAny<LoansRequest>())).Returns(_appResult.Object);
            IApplicationResult result = _sut.SubmitApplicationFor(sellerApplication);
            Assert.Equal(1, result.ApplicationId);
            Assert.True(result.Success);
        }
    }
}